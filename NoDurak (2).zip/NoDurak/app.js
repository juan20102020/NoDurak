
function navigateTo(page) {
  window.location.href = `${page}.html`;
}

document.getElementById("lobbyBtn").addEventListener("click", () => navigateTo("lobby"));
document.getElementById("turboBtn").addEventListener("click", () => navigateTo("turbo"));
document.getElementById("moneyBtn").addEventListener("click", () => navigateTo("money"));
document.getElementById("tournamentBtn").addEventListener("click", () => navigateTo("tournamet"));
